<?php 
    global $part_args;
    $settings = $part_args['settings'];
    $text = $settings['text'];
?>

<div class="rotating-text">
    <div class="inner">
        <div class="text">
            <?php echo $text ?>
        </div>
    </div>
</div>