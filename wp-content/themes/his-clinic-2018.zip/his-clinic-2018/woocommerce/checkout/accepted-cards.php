<div class="accepted-cards accepted-cards-mobile">
    <ul>
        <li><img src="<?php echo get_template_directory_uri() ?>/assets/img/McAfee-secure.png"></li>
        <li><img src="<?php echo get_template_directory_uri() ?>/assets/img/master.png"></li>
        <li><img src="<?php echo get_template_directory_uri() ?>/assets/img/thawte.png"></li>
        <li><img src="<?php echo get_template_directory_uri() ?>/assets/img/visa.png"></li>
    </ul>
</div>